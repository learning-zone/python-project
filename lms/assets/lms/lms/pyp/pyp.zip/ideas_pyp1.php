<?php
session_start();
include("../db.php");

$accyeardet=$_SESSION['AcademicYear'];
$mastername=$_REQUEST['mastername'];
$class=$_REQUEST['class'];


if($_REQUEST['master']!='')
$idn=$_REQUEST['master'];
else
$idn=$_POST['idn'];

$priority=$_POST['priority'];
$skills=$_POST['skills'];
$sql2=mysql_query("select * from ideas where id='$idn'");
while($r=mysql_fetch_array($sql2))
{
	$divi=$r['divi'];
	$class=$r['class'];
	$sub=$r['sub'];
	$skill2=$r['id']; 	
}
if(isset($_POST['update']))
{
	$cid=$_POST['cid'];
	for($i=0;$i<sizeof($cid);$i++)
	{
		$priority=$_POST['priority'.$cid[$i]];
		$skills=$_POST['skills'.$cid[$i]];
		$sql23="update   ideas_1 set idea='".addslashes($skills)."', posi='$priority' where id='$cid[$i]'";
		
		mysql_query($sql23);	
	}
		?>
		<Script language="JavaScript">
		alert("Updated successfully");
		</Script>
		<?php		
}
if(isset($_POST['save']))
{
	if($skills!='' and $priority!='')
	{
		$sql2=mysql_query("select * from   ideas_1 where acc_year='$accyeardet' and class='$class' and master_ideas='$skill1' and 	idea='$skills' and posi='$priority'");
		if(mysql_num_rows($sql2)>=1)
		{
			?>
			<Script language="JavaScript">
			alert("Duplicate entry not allowed");
			</Script>
			<?php
		}
		else
		{
			$sql44="INSERT INTO   ideas_1 (acc_year,class, master_ideas, idea, posi) VALUES ('$accyeardet', '$class', '".addslashes($skill2)."', '".addslashes($skills)."' , '$priority')";
	
			mysql_query($sql44);
			?>
			<Script language="JavaScript">
			alert("Updated successfully");
			</Script>
			<?php	
		}
	}
	else
	{
			?>
			<Script language="JavaScript">
			alert("Null data");
			</Script>
			<?php
		
	}
}
?>
<html>
<head><title>MASTER SKILLS</title>
</head>
<body>
<form name="frm" method="post">
<input type="hidden" name="idn" value="<?php echo $idn; ?>">
<table align='center' class='forumline' width='70%' >

<tr>
	<tr>
		<td align='center' class='head' nowrap>SUB SKILL</td>
		<td align='center' class='head' nowrap>ORDER</td>
	</tr>
	<tr>
      <td align='center' nowrap>
           <textarea name='skills' rows='3' cols='60' ></textarea>
		</td>
        <td align='center' nowrap>
        <input type='text' name='priority' value='' maxlength="2" size="2" width="2">
		</td>
		
	</tr>
</table>
<br>
  <div align='center' >
  <input type="submit" name="save" value="SAVE"  class='bgbutton'>
  <br>
  
  <br>
  <?php
$sql3=mysql_query("select id, idea , posi from   ideas_1 where acc_year='$accyeardet' and class='$class' and master_ideas='$skill2'");
if(mysql_num_rows($sql3)>=1)
{	
	?>
<br>
<table align='center' class='forumline' width='70%' >
<tr>
		<td align='center' class='head' nowrap>Sel
		</td>
		<td align='center' class='head' nowrap>SKILL</td>
		<td align='center' class='head' nowrap>ORDER</td>
		
	</tr>
	<?php
	while($r6=mysql_fetch_array($sql3))
	{
	echo "<tr><td align='center'  nowrap><input type='checkbox' name='cid[]' value='$r6[0]'>
		</td>
		 <td align='center' nowrap> <textarea name='skills$r6[0]' rows='3' cols='60' >$r6[1]</textarea>
        
		</td>
        <td align='center' nowrap>
        <input type='text' name='priority$r6[0]' value='$r6[2]' maxlength='2' size='2' width='2'>
		</td>
		
		</tr>";
	}
	?>
	<?php
	?>
	</table>
    <br>
  <div align='center' >
  <input type="submit" name="update" value="UPDATE"  class='bgbutton'>
	<?php
}
?>	
  
</form>
</body>
</html>