<html>
<?php
session_start();
require("../db.php");
$per00=$_SESSION['per00'];
if($per00==1)
{
	echo "<font color='red'>This link will work only for student's an parent's </font> ";
	die();
}

	$branch=$_SESSION['branch'];
	$sem=$_SESSION['sem'];	
	$grade=$sem;
	$as=$sem;
	$user=$_SESSION['user'];
$sql=mysql_query("select id ,student_id ,first_name ,last_name ,admission_id ,class_section_id, gender, dob from student_m where student_id='$user'");
while($r=mysql_fetch_array($sql))
{
	$class_section_id=$r['class_section_id'];
	$id=$r['id'];
	$dob=$r['dob'];
	$student_name=$r['first_name']." ".$r['last_name'];
	if($r[gender]=='M')
	$gen='Male';
	if($r[gender]=='F')
	$gen='Female';

}
$dob1=explode('-',$dob);
$b_year=$dob1[0];
$b_day=$dob1[2];
$b_month=$dob1[1];
	$d=date("d");
	$m=date("m");
	$y=date("Y");
	if($b_month<$m)
	{
		$age_yr=$y-$b_year;
	}
	else
	{
		if($b_month==$m)
		{
			if($b_day<=$d)
			{
				$age_yr=$y-$b_year;
			}
			else
			{
				$age_yr=($y-$b_year)-1;
			}
		}
		else
		{
			$age_yr=($y-$b_year)-1;
		}
		
	}
$ag=$age_yr;	
$ad =$_SESSION['AcademicYear'];

$fs =$student_name;
$stud =$user;



     
?>
<head>
<script>
function cli()
{
  document.frmMedicaldetail.action='day_stud.php';
  document.frmMedicaldetail.submit();
}
function printReport()
{
	prn.style.display='none';
	print(this.form);
	prn.style.display=='';
}
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Sick Report</title>
</head>
<body>

<SCRIPT language=javascript>
function trim(par)
{	
	y=par.length;
	ret='';
	for (i=0;i<y;i++)
	{
		if (par.charAt(i)!=' ')
		{
			ret=ret+par.charAt(i);
		}
	}
	return ret;
}
function frmMedicaldetail_submit()
{
	if (trim(document.frmMedicaldetail.cmbSeen.value)== "")
	{
		window.alert("Please Select Doctor Name");
		document.frmMedicaldetail.cmbSeen.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtPresenting.value == "")
	{
		window.alert("Please Enter presnting Complaints");
		
		document.frmMedicaldetail.txtPresenting.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtSalient.value == "")
	{
		window.alert("Please Enter Salient Findings");
		
		document.frmMedicaldetail.txtSalient.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtProvisional.value  == "")
	{
		window.alert("Please Enter Provisional Diagnostics");
		document.frmMedicaldetail.txtProvisional.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtInvestigations.value  == "")
	{
		window.alert("Please Enter Investigations");
		document.frmMedicaldetail.txtInvestigations.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtTreatment.value  == "")
	{
		window.alert("Please Enter treatment");
		document.frmMedicaldetail.txtTreatment.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtRecommendations.value  == "")
	{
		window.alert("Please Enter Recommendations");
		document.frmMedicaldetail.txtRecommendations.focus();
		return false;
	}
		frmMedicaldetail.txhControl.value = "Submit";
	        document.frmMedicaldetail.submit();
}	
function frmMedicaldetail_submit1()
{
	frmMedicaldetail.txhControl.value = "Back";
	document.frmMedicaldetail.submit();
}	
</SCRIPT>
<form name="frmMedicaldetail" method="post" action='day_studs.php'>
<br>

<?php
      $rfg=execute("select * from doc_detail where stud_id='$stud' and course_id='$as'");
     
if(mysql_num_rows($rfg)==0)
die("Records not found ");


 $fgb=fetcharray($rfg);
?>
<table class="formtable" width="55%" id="table2" align=center border=1>


<tr><td align="Center" height="30"  colspan=4 class=head>
Sick Report Of <?php echo $fs?></td></tr>
<tr class="keyrow">
					<td width="25%" >&nbsp;<?php echo $_SESSION['semname']; ?></td>
					<?php
					    	 $cr=execute("select * from course_year where year_id='$sem'");
				   $rtt=fetcharray($cr);
		
					?>
					<td width="25%" >&nbsp;<?php echo $rtt[year_name]?></font></td>
					<tr>
					<td width="25%" >&nbsp;Sex</td>
					<td width="25%" >&nbsp;<?php echo $gen?></td>
					</tr>
				</tr>
				<tr>
				<td width="25%" >&nbsp;Age (yrs.)</td>
					<td width="25%">&nbsp;<?php echo $ag?></tr>
					
			
<tr>
					<td width="25%" >&nbsp;Academic Year</td>
					<td width="25%">&nbsp;<?php echo $ad?></td>
					
					</tr>
					</table>
					<br>
					<table border='1' align='center' width = "70%">
					<tr><td colspan=6 align=center  class=row3 >Date Wise Details</td></tr>
	     <tr>
		         <td align=center>&nbsp;Sl No</td>
		        <td align=center>&nbsp;Seen By</td>
			<td align=center>&nbsp;Date</td>
			<td align=center>&nbsp;Description</td>
			<td align=center>&nbsp;Treatment</td>
			<td align=center>&nbsp;Outcome</td>
		</tr>
					<?php
					      $slno=1;
					      $rcb=execute("select * from doc_detail where stud_id='$stud' order by d_date");
					      while($rrf=fetcharray($rcb))
					     {
					?>
			<tr>
			<td >&nbsp;<?php echo $slno?></td>
			<td align=center>&nbsp;<?php echo $rrf[doc_name]?></td>
			<td >&nbsp;<?php echo date("d-m-Y",strtotime($rrf[d_date]))?></td>
			<td align=center>&nbsp;<?php echo $rrf[complaints]?></td>
			<td align=center>&nbsp;<?php echo $rrf[treatment]?></td>
			<td align=center>&nbsp;<?php echo $rrf[remarks]?></td>
		</tr>
		
				
			<?php
			     $slno++;
			     }
			?>
		
	
</table>
<br>
<center>
  &nbsp;
<input type=button name='prn' value="PRINT" class='bgbutton' onclick='printReport()'>
</center>
</div>
</form>
</body>

</html>
