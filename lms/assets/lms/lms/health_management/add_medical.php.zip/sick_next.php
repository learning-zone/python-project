<html>
<?php
include("../db.php");
if($_REQUEST)
{
	$grade=$_REQUEST['grade'];  
	$stud =$_REQUEST['stud'];
	$fs =$_REQUEST['fs'];
	$ad =$_REQUEST['ad'];
	$ag =$_REQUEST['ag'];
	$gen =$_REQUEST['gen'];
	$adm =$_REQUEST['adm'];
	$branch=$_REQUEST['branch'];
	$sem=$_REQUEST['sem'];
	$class_section_id=$_REQUEST['class_section_id'];
}
if($_POST)
{
	$branch=$_POST['branch'];
	$sem=$_POST['sem'];
	$class_section_id=$_POST['class_section_id'];
	$gob = $_POST['gob'];
	$doct = $_POST['doct'];
	$penal_day = $_POST['penal_day'];
	$penal_month = $_POST['penal_month'];
	$penal_year = $_POST['penal_year'];
	$penal_hr = $_POST['penal_hr'];
	$penal_sec = $_POST['penal_sec'];
	$ams = $_POST['ams'];
	$txtPresenting = $_POST['txtPresenting'];
	$txtTreatment = $_POST['txtTreatment'];
	$txtRecommendations = $_POST['txtRecommendations'];
}
?>
<head>
<script language='Javascript'>
function reload()
{
   document.frmMedicaldetail.action='sick_stud.php';
   document.frmMedicaldetail.submit();
}
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Sick Report</title>
</head>
<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form name="frmMedicaldetail" method="post" action='sick_next.php'>
<input type=hidden name='grade' value='<?php echo $grade?>'>
<input type=hidden name='ad' value='<?php echo $ad?>'>
<input type=hidden name='gen' value='<?php echo $gen?>'>
<input type=hidden name='adm' value='<?php echo $adm?>'>
<input type=hidden name='ag' value='<?php echo $ag?>'>
<input type=hidden name='stud' value='<?php echo $stud?>'>
<input type=hidden name='branch' value='<?php echo $branch?>'>
<input type=hidden name='sem' value='<?php echo $sem?>'>
<input type=hidden name='class_section_id' value='<?php echo $class_section_id?>'>

<SCRIPT language=javascript>
		
function trim(par)
{	
	
	y=par.length;
	ret='';
	for (i=0;i<y;i++)
	{
		if (par.charAt(i)!=' ')
		{
			ret=ret+par.charAt(i);
		}
	}
	
	return ret;
	
}
funtion reload()
{
    document.frmMedicaldetail.action="sick_studs.php";
    document.frmMedicaldetail.submit();
}

function frmMedicaldetail_submit()
{
	if (trim(document.frmMedicaldetail.cmbSeen.value)== "")
	{
		window.alert("Please Select Doctor Name");
		document.frmMedicaldetail.cmbSeen.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtPresenting.value == "")
	{
		window.alert("Please Enter presnting Complaints");
		
		document.frmMedicaldetail.txtPresenting.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtSalient.value == "")
	{
		window.alert("Please Enter Salient Findings");
	        document.frmMedicaldetail.txtSalient.focus();
                return false;
	}
	if (document.frmMedicaldetail.txtProvisional.value  == "")
	{
		window.alert("Please Enter Provisional Diagnostics");
		document.frmMedicaldetail.txtProvisional.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtInvestigations.value  == "")
	{
		window.alert("Please Enter Investigations");
		document.frmMedicaldetail.txtInvestigations.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtTreatment.value  == "")
	{
		window.alert("Please Enter treatment");
		document.frmMedicaldetail.txtTreatment.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtRecommendations.value  == "")
	{
		window.alert("Please Enter Recommendations");
		document.frmMedicaldetail.txtRecommendations.focus();
		return false;
	}
		frmMedicaldetail.txhControl.value = "Submit";
	document.frmMedicaldetail.submit();
}	

function frmMedicaldetail_submit1()
  {
	frmMedicaldetail.txhControl.value = "Back";
	document.frmMedicaldetail.submit();
  }	

		</SCRIPT>

			<table class='forumline' cellspacing=0 width="55%" id="table2" align=center>
			<tr>
			<td vAlign="top" align="Center" height="30"  colspan=5 class=head>
			Student Sick Report for - <?php echo $fs?></td>
			
		</tr>
				        <tr class="keyrow">
					<td width="25%" >&nbsp;<?php echo $_SESSION['semname']; ?></td>
					<td width="25%" >
					<?php
					
					 $cr=execute("select * from course_year where year_id='$sem'");
				   $rtt=fetcharray($cr);
				   	?>
					<?php echo $rtt[year_name]?></td>
					<td width="25%" >&nbsp;Age(yrs.)</td>
					<td width="25%">
					<?php echo $ag?></td>
				</tr>
				        <tr class="keyrow">
					<td width="25%" >&nbsp;Sex</td>
					<td width="25%" >
					<?php echo $gen?></td>
					<td width="25%">&nbsp;Admission Type</td>
					<td width="25%">
					<?php
					     $ggt=execute("select * from admission where id='$adm'");
					     $g=fetcharray($ggt);
					?><?php echo $g[name]?></td>
				</tr>
				<tr class="keyrow">
					<td width="25%" >&nbsp;Academic Year</td>
					<td width="25%"><?php echo $ad?></td>
					<td width="25%" colspan='2'></td></tr>

				
					<?php
					//$query=execute("select distinct(doc_name) from doc_detail");
                     //$rc=rowcount($query);
					//if($rc>0)
					//{
					?>
					
					<?php
                         //               for($i=0;$i<$rc;$i++)
                    		//	{
							//		$rt=fetcharray($query,$i);
		 		              //  if($cmbSeen==$rt[0])
      							//{
          						//	echo("<option value='$rt[0]' selected>$rt[0]</option>");
							//}
						  //else
	    					//	{
	    					//		echo("<option value='$rt[0]'>$rt[0]</option>");
							//}
									
                             //           }
					//}
?>
<!-- </select></td><tr> -->
                                       
					
					        <tr vAlign="top" align="left">
								<td class="keycell" >&nbsp;Seen By</td>
								<td class="keycell" colSpan="3">
								
								
								<input type=text name="doct">
				                </td>
				            </tr>
				<?php
				   
				?>
				<tr>
				<td >&nbsp;Select Date</td>
				<td width='50%'>
				
				<select name="penal_day">
<?php
$j=date('d');
for($i=1;$i<=31;$i++)
{
	$sel='';
	if($j==$i)
	$sel='selected';
	echo "<option value=$i $sel >$i</option>";
}
?>
</select>
<select name="penal_month">
<?php
$j=date('m');
for($i=1;$i<=12;$i++)
{
	$sel='';
	if($j==$i)
	$sel='selected';
	echo "<option value=$i $sel >$i</option>";
}
?>
</select>
<select name="penal_year">
<?php
$j=date('Y');
$d=$j-1;
for($i=$d;$i<=$j+1;$i++)
{
	$sel='';
	if($j==$i)
	$sel='selected';
	echo "<option value=$i $sel >$i</option>";
}
?>
</select>

</td>
				<td  colspan=2 width='50%'>&nbsp;Time<select name="penal_hr">
  <?php
    
    for($i='1';$i<=12;$i++)
  {
        if($i<10)
	{
	  $i='0'.$i;
	}
	$sel='selected';
	echo "<option value=$i $sel >$i</option>";
 }
?>
</select>
<select name="penal_sec">
<?php
for($i='1';$i<=59;$i++)
{
        if($i<10)
	{
	  $i='0'.$i;
	}
	
	$sel='selected';
	echo "<option value=$i $sel >$i</option>";
}
?>
</select>
<select name='ams'>
<option>AM</option>
<option>PM</option>
</select>
</td>

			</tr>
				<tr>
					<td class="keycell" >&nbsp;Description</td>
					<td colSpan="3"><textarea name="txtPresenting" rows="4" cols="60"></textarea></td>
				</tr>
			
				<tr>
					<td class="keycell">&nbsp;Treatment</td>
					<td colSpan="3">
					<textarea name="txtTreatment" rows="4" cols="60"></textarea></td>
				</tr>
				<tr>
					<td class="keycell" >&nbsp;Outcome</td>
					<td colSpan="3">
					<textarea name="txtRecommendations" rows="4" cols="60"></textarea>
					</td>
				</tr>				
				<?php
				     if(isset($gob))
				     {
				       $penaly=$_POST['penal_year'];
				       $penalm=$_POST['penal_month'];
				       $penald=$_POST['penal_day'];
				       $ddv=$penaly."-".$penalm."-".$penald;
				       $ti=$_POST['penal_hr'];
				       $tim=$_POST['penal_sec'];
				       $tims=$_POST['ams'];
				       $timr=$ti."-".$tim."-".$tims;
				       
				       $c=execute("select * from doc_detail where stud_id='$stud' and course_id='$as' and d_date='$ddv'");
				     
				       if(rowcount($c)==0)
				       {
				         $gj=execute("insert into doc_detail(stud_id,course_id,age,sex,adm_type,acc_year,doc_name,d_date,time,complaints,treatment,remarks)values('$stud','$grade','$ag','$gen','$adm','$ad','$doct','$ddv','$timr','".addslashes($txtPresenting)."','".addslashes($txtTreatment)."','".addslashes($txtRecommendations)."')");
						 //echo "SICK REPORT INSERTED SUCESSFULLY";
						 ?>
						 <script language="JavaScript" type="text/javascript">
						 alert("SICK REPORT INSERTED SUCESSFULLY");
						 reload();
                         </script>
						 <?php
				       }
				       else
				       {
				         //echo "Data Entered for the Selected Student Id";
						 ?>
						 <script language="JavaScript" type="text/javascript">
						 alert("Data Entered for the Selected Student Id");
                         </script>
						 <?php
						 die();
				       }
				     }
				
				?>
			</table>
		<br>
			<center>
			<input type=submit name='subn' value='Go Back' class='bgbutton' onclick='reload()'>
			<input type=submit name='gob' value='Submit' class='bgbutton'>
			</center>
	</form>

</body>

</html>
