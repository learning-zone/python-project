<html>
<?php
  include("../db.php");
  if($_REQUEST)
  {
		$penal_day = $_REQUEST['penal_day'];
		$penal_month = $_REQUEST['penal_month'];
		$penal_year = $_REQUEST['penal_year'];
		
		$penal_days = $_REQUEST['penal_days'];
		$penal_months = $_REQUEST['penal_months'];
		$penal_years = $_REQUEST['penal_years'];
		
		$mtype = $_REQUEST['mtype'];
		$penal_from=$penal_year."-".$penal_month."-".$penal_day;
		$penal_to=$penal_years."-".$penal_months."-".$penal_days;
  }
  if($_POST)
  {
		$mtype=$_POST['mtype'];
		$penal_to=$_POST['penal_to'];
		$penal_from=$_POST['penal_from'];
  
  }
?>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="File-List" href="SICK%20REPORT_files/filelist.xml">
<title>Student details</title>
</head>
<body>
<form name='frm' method="POST" action='day_studs.php'>
<input type='hidden' name='penal_day' value='<?php echo $penal_day?>'>
<input type='hidden' name='penal_month' value='<?php echo $penal_month?>'>
<input type='hidden' name='penal_year' value='<?php echo $penal_year?>'>
<input type='hidden' name='penal_days' value='<?php echo $penal_days?>'>
<input type='hidden' name='penal_months' value='<?php echo $penal_months?>'>
<input type='hidden' name='penal_years' value='<?php echo $penal_years?>'>
<input type='hidden' name='mtype' value='<?php echo $mtype?>'>
<input type='hidden' name='penal_from' value='<?php echo $penal_from?>'>
<input type='hidden' name='penal_to' value='<?php echo $penal_to?>'>

<table border='1'  width="90%" align='center'> 
		<tr><td colspan=6 align=center class=head>Student Details</td></tr>
		<tr>
		        <td align=center nowrap>&nbsp;Student Name</td>
			<td align=center nowrap>&nbsp;Identification Number</td>
			<td align=center nowrap>&nbsp;Sex</td>
			<td align=center nowrap>&nbsp;Admission Type</td>
		</tr>
		<?php

			  $df=execute("select a.*,b.first_name,b.last_name,b.course_yearsem from doc_detail a,student_m b where a.d_date between '$penal_from' and '$penal_to' and a.stud_id=b.student_id group by a.stud_id");
		     while($ddf=fetcharray($df))
		       {
		         $mm=$ddf[adm_type];
			 $fd=$ddf[first_name]." ".$ddf[last_name];
			 $ecc=execute("select * from admission where id='$mm'");
			 $ec=fetcharray($ecc);
			 
		        
		?>
		<tr>
			<td >&nbsp;<?php echo $fd?></td>
			<td align=center><a href='day_studs.php?stud=<?php echo $ddf[stud_id]?>&dt=<?php echo date("d-m-Y",strtotime($ddf[d_date]))?>&fs=<?php echo $fd?>&as=<?php echo $ddf[course_id]?>&sem=<?php echo $ddf[course_yearsem]?>&ad=<?php echo $ddf[acc_year]?>&ag=<?php echo $ddf[age]?>&gen=<?php echo $ddf[sex]?>&adm=<?php echo $ddf[adm_type]?>&pf=<?php echo $penal_from?>&pt=<?php echo $penal_to?>&mtype=<?php echo $mtype?>&penal_from=<?php echo $penal_from?>&penal_to=<?php echo $penal_to?>'>
 			&nbsp;<?php echo $ddf[stud_id]?></a></td>
			<td >&nbsp;<?php echo $ddf[sex]?></td>
			<td align=center>&nbsp;<?php echo $ec[name]?></td>
		</tr>
		<?php
		   }
		?>
		
	</table>
</div>
</form>
</body>
</html>
