<?php
	include("../db.php");
    //print_r($_POST);
	$grade=$_REQUEST['grade'];  
	$stud =$_REQUEST['stud'];
	$fs =$_REQUEST['fs'];
	$id =$_REQUEST['id'];
	$ad =$_REQUEST['ad'];
	$ag =$_REQUEST['ag'];
	$gen =$_REQUEST['gen'];
	$adm =$_REQUEST['adm'];
	$branch=$_REQUEST['branch'];
	$sem=$_REQUEST['sem'];
	$class_section_id=$_REQUEST['class_section_id'];
	$branch=$_POST['branch'];
	$sem=$_POST['sem'];
	$class_section_id=$_POST['class_section_id'];
	$gob = $_POST['gob'];
	$doct = $_POST['doct'];
	$txtPresenting = $_POST['txtPresenting'];
	$txtTreatment = $_POST['txtTreatment'];
	$txtRecommendations = $_POST['txtRecommendations'];
	$penal_day = $_POST['penal_day'];
	$penal_month = $_POST['penal_month'];
	$penal_year = $_POST['penal_year'];
	$penal_hr = $_POST['penal_hr'];
	$penal_sec = $_POST['penal_sec'];
	$ams = $_POST['ams'];
	$dts=$_POST['dts'];
if(isset($gob))
{
	$dts=$penal_year."-".$penal_month."-".$penal_day;
	$timr=$penal_hr."-".$penal_sec."-".$ams;
	$gj=execute("update doc_detail set doc_name='".addslashes($doct)."',d_date='".addslashes($dts)."',time='".addslashes($timr)."',complaints='".addslashes($txtPresenting)."',treatment='".addslashes($txtTreatment)."',remarks='".addslashes($txtRecommendations)."' where id='$id'");
	$dcv2=execute("select * from doc_detail where id='$id'");
	?>
		<script language="JavaScript" type="text/javascript">
       	 	alert("MODIFIED SUCESSFULLY");
        </script>
	<?php
	
}

?>

<html>

<head>
<script>
       function reload()
       {
          document.frmMedicaldetail.action='edit_stud.php';
		  document.frmMedicaldetail.submit();
       }
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
</head>
<body>
<p>&nbsp;</p>
<p>&nbsp;</p>

<SCRIPT language=javascript>
		
function trim(par)
{	
	
	y=par.length;
	ret='';
	for (i=0;i<y;i++)
	{
		if (par.charAt(i)!=' ')
		{
			ret=ret+par.charAt(i);
		}
	}
		return ret;
}
funtion reload()
{
    document.frmMedicaldetail.action="edit_studs.php";
    document.frmMedicaldetail.submit();
}

function frmMedicaldetail_submit()
{
	if (trim(document.frmMedicaldetail.cmbSeen.value)== "")
	{
		window.alert("Please Select Doctor Name");
		document.frmMedicaldetail.cmbSeen.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtPresenting.value == "")
	{
		window.alert("Please Enter presnting Complaints");
		
		document.frmMedicaldetail.txtPresenting.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtSalient.value == "")
	{
		window.alert("Please Enter Salient Findings");
		
		document.frmMedicaldetail.txtSalient.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtProvisional.value  == "")
	{
		window.alert("Please Enter Provisional Diagnostics");
		document.frmMedicaldetail.txtProvisional.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtInvestigations.value  == "")
	{
		window.alert("Please Enter Investigations");
		document.frmMedicaldetail.txtInvestigations.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtTreatment.value  == "")
	{
		window.alert("Please Enter treatment");
		document.frmMedicaldetail.txtTreatment.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtRecommendations.value  == "")
	{
		window.alert("Please Enter Recommendations");
		document.frmMedicaldetail.txtRecommendations.focus();
		return false;
	}
		frmMedicaldetail.txhControl.value = "Submit";
	document.frmMedicaldetail.submit();
}	

function frmMedicaldetail_submit1()
  {
	frmMedicaldetail.txhControl.value = "Back";
	document.frmMedicaldetail.submit();
  }	

		</SCRIPT>
        
        
<?php
	while($r=mysql_fetch_array($dcv2))
	{
		 $grade=$r['course_id'];
		 $ad=$r['acc_year'];
		 $gen=$r['sex'];
		 $adm=$r['name'];
		 $stud=$r['stud_id'];
		$txtPresenting = $r['complaints'];
		$txtTreatment = $r['treatment'];
		$txtRecommendations = $r['remarks'];
		$tempdate=$r['d_date'];
	}
	$date1=explode('-',$tempdate);
	
	$penal_day = $date1[2];
	$penal_month =  $date1[1];
	$penal_year =  $date1[0];



$ser2="select first_name, last_name from student_m where student_id='$stud'";
$ser=mysql_query($ser2);
while($r1=mysql_fetch_array($ser))
{
	$studentname=$r1['first_name'].' '.$r1['last_name'];
}
?>



		      <form name="frmMedicaldetail" method="post" action='edit_next.php'>
      <input type=hidden name='grade' value='<?php echo $grade?>'>
      <input type=hidden name='ad' value='<?php echo $ad?>'>
      <input type=hidden name='gen' value='<?php echo $gen?>'>
      <input type=hidden name='adm' value='<?php echo $adm?>'>
      <input type=hidden name='ag' value='<?php echo $ag?>'>
      <input type=hidden name='stud' value='<?php echo $stud?>'>
      <input type=hidden name='dts' value='<?php echo $dts?>'>
      <input type=hidden name='fs' value='<?php echo $fs?>'>
    <input type=hidden name='branch' value='<?php echo $branch?>'>
    <input type=hidden name='sem' value='<?php echo $sem?>'>
    <input type=hidden name='class_section_id' value='<?php echo $class_section_id?>'>
    <input type="hidden" name="id" value="<?=$id?>">

			<table class='forumline' cellspacing=0 width="55%" id="table2" align=center>
			<tr>
			<td vAlign="top" align="center" height="30" colspan=5 class=head>
			Student Sick Report for - <?php echo $studentname?></td>
			
		</tr>
				<tr class="keyrow">
					<td width="25%" >&nbsp;<?php echo $_SESSION['semname']; ?></td>
					<?php
					    	 $cr=execute("select * from course_year where year_id='$sem'");
				   $rtt=fetcharray($cr);
		
					?>
					<td width="25%" >&nbsp;<?php echo $rtt[year_name]?></font></td>
					<td width="13%" >&nbsp;Age(yrs.)</td>
					<td width="38%" ><?php echo $ag?></td>
				</tr>
				<tr class="keyrow">
					<td width="16%" >&nbsp;Sex</td>
					<td width="33%"><?php echo $gen?></td>
					<td width="13%">&nbsp;Admission Type</td>
					<td width="38%" >
					<?php
					    
					     $dcv=execute("select * from doc_detail where id='$id'");
						 $cvv=fetcharray($dcv);
					
					?>
					<?php echo $adm?></td>
				</tr>
				    <tr class="keyrow">
					<td width="16%">&nbsp;Academic Year</td>
					<td width="33%"><?php echo $ad?></td>
					<td colspan='2'></td></tr>

					
					
					        <tr vAlign="top" align="left">
					        <td class="keycell" >&nbsp;Doctor Name</td>
					        <td class="keycell" colSpan="3">					        
					        <input type=text name="doct" value='<?php echo $cvv[doc_name]?>'>
				                </td>
				                </tr>
				<?php
				   
				?>
				<tr>
				<td >&nbsp;Select Date</td>
				<td width='33%'>				
				<select name="penal_day">
<?php
				for($i=1;$i<=31;$i++)
				{
					if($penal_day==$i)
					{
						echo "<option value='$i' selected >$i</option>";
					}
					else
					{
						echo "<option value='$i'>$i</option>";
					} 
				}
?>
</select>
<select name="penal_month">
<?php
for($i=1;$i<=12;$i++)
{	
	if($penal_month==$i)
	{
	 	echo "<option value='$i' selected>$i</option>";
	}
	else
	{
	  	echo "<option value='$i'>$i</option>";
	} 
}
?>
</select>
<select name="penal_year">
<?php
$j=date('Y');
$d=$j-1;
for($i=$d;$i<=$j+1;$i++)
{
	if($penal_year==$i)
	{
	   $sel='selected';
	   echo "<option value=$i $sel >$i</option>";
	}
	else
	{
	  echo "<option value='$i'>$i</option>";
	} 
}
?>
</select></td>
<td >Time</td>
<?php
     $dm=explode("-",$cvv['time']);
?>
<td colspan='2' width='38%'>
<select name="penal_hr">
  <?php
   for($il='1';$il<=12;$il++)
  {
        if($il<10)
	{
	  $il='0'.$il;
	}
	if($dm[0]=='' || $dm[0]=='0')
	{
	  $p=$il;
	}
	else
	{
	  $p=$dm[0];
	}
	
	if($p==$il)
	{
	       echo "<option value='$il' selected >$il</option>";
	}
	else
	{
	       echo "<option value=$il>$il</option>";
	} 
 }
?>
</select>
<select name="penal_sec">
<?php

for($is1=1;$is1<=59;$is1++)
{
        if($is1<10)
	{
	  $is1='0'.$is1;
	}
	if($dm[1]=='' || $dm[1]=='0')
	{
	  
	  $qq=$is1;
	}
	else
	{
	
	  $qq=$dm[1];
	}
	$sel='';
	if($qq==$is1)
	{
	 $sel='selected';
	 echo "<option value='$is1' $sel>$is1</option>";
	}
	else
	{
	  echo "<option value='$is1'>$is1</option>";
	} 
}
?>
</select>
<select name='ams'>
<?php
if($dm[2]=="AM")
{
	$sj="selected";
	$sk="";
}
if($dm[2]=="PM")
{
	$sk="selected";
	$sj="";
}
?>
<option value="AM" <?php echo $sj?>>AM</option>
<option value="PM" <?php echo $sk?>>PM</option>
</select>
</td>
</tr>

				<?php
			
			
						
					  $dcv=execute("select * from doc_detail where id='$id'");
					  $cvv=fetcharray($dcv);
				?>
				<input type=hidden name='cvv1' value='<?php echo $cvv[id]?>'>
				<tr>
					<td class="keycell">Description</td>
					<td colSpan="3">
					<textarea name="txtPresenting" rows="4" cols="60"><?php echo $cvv[complaints]?></textarea>
					</td>
				</tr>
			
				<tr>
					<td class="keycell">&nbsp;Treatment</td>
					<td colSpan="3">
					<textarea name="txtTreatment" rows="4" cols="60"><?php echo $cvv[treatment]?></textarea>
					</td>
				</tr>
				<tr>
					<td class="keycell">&nbsp;Outcome</td>
					<td colSpan="3">
					<textarea name="txtRecommendations" rows="4" cols="60"><?php echo $cvv[remarks]?></textarea>
					</font></td>
				</tr>			
		</table>
        <br>
        <center>
        <div>
			<input type=submit name='subn' value='Go Back' class='bgbutton' onclick='reload()'>
			<input type=submit name='gob' value='Modify' class='bgbutton'>
            </div>
            </center>
			
	</form>

</body>
</html>
