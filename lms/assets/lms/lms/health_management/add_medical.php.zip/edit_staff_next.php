<html>
<?php
    include("../db.php");
	$staf=$_POST['staf'];
  $stafd=$_POST['stafd'];
  
  
$stud = $_POST['stud'];
$fn = $_POST['fn'];
$gen = $_POST['gen'];

$doct = $_POST['doct'];
$penal_day = $_POST['penal_day'];
$penal_month = $_POST['penal_month'];
$penal_year = $_POST['penal_year'];
$penal_hr = $_POST['penal_hr'];
$penal_sec = $_POST['penal_sec'];
$ams = $_POST['ams'];
$txtPresenting = $_POST['txtPresenting'];
$txtTreatment = $_POST['txtTreatment'];
$txtRecommendations = $_POST['txtRecommendations'];
$subn = $_POST['subn'];

$dts = $_POST['dts'];
?>
<head>
<script>
    function cli()
  {
     document.frmMedicaldetail.action='edit_staffs.php';
     document.frmMedicaldetail.submit();
  }
 
function printReport()
{
	prn.style.display='none';
	print(this.form);
	prn.style.display=='';
}
</script>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
</head>
<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form name="frmMedicaldetail" method="post" action='edit_staff_next.php'>
<input type=hidden name='gen' value='<?php echo $gen?>'>
<input type=hidden name='stud' value='<?php echo $stud?>'>
<input type=hidden name='staf' value='<?php echo $staf?>'>
<input type=hidden name='aa' value='<?php echo $aa?>'>
<input type=hidden name='stafd' value='<?php echo $stafd?>'>
<input type=hidden name='dts' value='<?php echo $dts?>'>
<input type=hidden name='id' value='<?php echo $id?>'>
<SCRIPT language=javascript>
		
		function trim(par)
{	
	
	y=par.length;
	ret='';
	for (i=0;i<y;i++)
	{
		if (par.charAt(i)!=' ')
		{
			ret=ret+par.charAt(i);
		}
	}
	
	return ret;
	
}

function frmMedicaldetail_submit()
{
	if (trim(document.frmMedicaldetail.cmbSeen.value)== "")
	{
		window.alert("Please Select Doctor Name");
		document.frmMedicaldetail.cmbSeen.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtPresenting.value == "")
	{
		window.alert("Please Enter presnting Complaints");
		
		document.frmMedicaldetail.txtPresenting.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtSalient.value == "")
	{
		window.alert("Please Enter Salient Findings");
		
		document.frmMedicaldetail.txtSalient.focus();
        return false;
	}
	if (document.frmMedicaldetail.txtProvisional.value  == "")
	{
		window.alert("Please Enter Provisional Diagnostics");
		document.frmMedicaldetail.txtProvisional.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtInvestigations.value  == "")
	{
		window.alert("Please Enter Investigations");
		document.frmMedicaldetail.txtInvestigations.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtTreatment.value  == "")
	{
		window.alert("Please Enter treatment");
		document.frmMedicaldetail.txtTreatment.focus();
		return false;
	}
	if (document.frmMedicaldetail.txtRecommendations.value  == "")
	{
		window.alert("Please Enter Recommendations");
		document.frmMedicaldetail.txtRecommendations.focus();
		return false;
	}
		frmMedicaldetail.txhControl.value = "Submit";
	document.frmMedicaldetail.submit();
}	

function frmMedicaldetail_submit1()
{
	frmMedicaldetail.txhControl.value = "Back";
	document.frmMedicaldetail.submit();
}	

		</SCRIPT>

			<table class="formtable" width="70%" id="table2" align=center >
				
			<tr>
			<td vAlign="top" align="Center" height="30"  colspan=4 class=head>Edit Staff Sick Report for - <?php echo $fn?></td>
			
		</tr>
		         <?php
				 
				 
                              $rfg=execute("select * from doc_staff where slno='$stud' and group_id='$staf' and des_id='$stafd' and d_date='$dts'");
			      $fgb=fetcharray($rfg);

                         ?>
				<tr class="keyrow">
					<td width="16%" >&nbsp;Sex</td>
					<td width="33%" ><?php echo $gen?></td>
					<td width="14%" >&nbsp;Designation</td>
					<?php
					     $ggt=execute("select * from staff_des where d_id='$stafd'");
					     $g=fetcharray($ggt);
					
					?>
					<td width="37%" ><?php echo $g[d_name]?></td>
				</tr>
				
					<tr vAlign="top" align="left">
					<td class="keycell" >&nbsp;Seen By Others</td>
					<td class="keycell" colSpan="3">
					
					<input type=text name="doct" value='<?php echo $fgb[doc_name]?>'>
				</td>
				</tr>
				<tr vAlign="top" align="left">
				<td class="keycell" >&nbsp;Date</td>
					<td width="33%"><select name="penal_day">
<?php
$dd=explode("-",$fgb[d_date]);
$j=date('d');
for($i=1;$i<=31;$i++)
{
	if($dd[2]=='' || $dd[2]=='0')
	{
	  $p=$j;
	}
	else
	{
	  $p=$dd[2];
	}
	
	if($p==$i)
	{
	       echo "<option value='$i' selected >$i</option>";
	}
	else
	{
	       echo "<option value=$i>$i</option>";
	} 
}
?>
</select>
<select name="penal_month">
<?php

$j=date('m');
for($i=1;$i<=12;$i++)
{
	if($dd[1]=='' || $dd[1]=='0')
	{
	  $q=$j;
	}
	else
	{
	  $q=$dd[1];
	}
	$sel='';
	if($q==$i)
	{
	 $sel='selected';
	 echo "<option value=$i $sel>$i</option>";
	}
	else
	{
	  echo "<option value=$i>$i</option>";
	} 
}
?>
</select>
<select name="penal_year">
<?php

$j=date('Y');
$d=$j-1;
for($i=$d;$i<=$j+1;$i++)
{
	$sel='';
	if($j==$i)
	{
	   $sel='selected';
	   echo "<option value=$i $sel >$i</option>";
	}
	else
	{
	  echo "<option value=$i>$i</option>";
	} 
}
?>
</select></td><td >&nbsp;Time</td>
<td colspan='2' width='37%'>
<select name="penal_hr">
  <?php
   $dm=explode("-",$fgb['time']);
    for($i='1';$i<=12;$i++)
  {
         if($i<10)
	{
	  $i='0'.$i;
	}
	if($dm[0]=='' || $dm[0]=='0')
	{
	  $p=$i;
	}
	else
	{
	  $p=$dm[0];
	}
	
	if($p==$i)
	{
	       echo "<option value='$i' selected >$i</option>";
	}
	else
	{
	       echo "<option value=$i>$i</option>";
	} 
 }
?>
</select>
<select name="penal_sec">
<?php

for($i='1';$i<=59;$i++)
{
        if($i<10)
	{
	  $i='0'.$i;
	}
	if($dm[1]=='' || $dm[1]=='0')
	{
	  $qq=$i;
	}
	else
	{
	$qq=$dm[1];
	}
	$sel='';
	if($qq==$i)
	{
	 $sel='selected';
	 echo "<option value=$i $sel>$i</option>";
	}
	else
	{
	  echo "<option value=$i>$i</option>";
	} 
}
?>
</select>
<select name='ams'>
<?php
if($dm[2]=="AM")
{
	$sj="selected";
	$sk="";
}
if($dm[2]=="PM")
{
	$sk="selected";
	$sj="";
}
?>
<option value="AM" <?php echo $sj?>>AM</option>
<option value="PM" <?php echo $sk?>>PM</option>
</select>
</td>
				</tr>
				<tr>
					<td class="keycell" >&nbsp;Complaints</td>
					<td colSpan="3">
					<textarea name="txtPresenting" rows="4" cols="60"><?php echo $fgb[complaints]?></textarea>
					</td>
				</tr>
			
				<tr>
					<td class="keycell">&nbsp;Treatment</td>
					<td colSpan="3">
					<textarea name="txtTreatment" rows="4" cols="60"><?php echo $fgb[treatment]?></textarea></td>
				</tr>
				<tr>
					<td class="keycell" >&nbsp;Remarks</td>
					<td colSpan="3">
					<textarea name="txtRecommendations" rows="4" cols="60"><?php echo $fgb[remarks]?></textarea>
					</td>
				</tr>
				
				<?php
				     if(isset($subn))
				     {
				      $penal=$penal_year."-".$penal_month."-".$penal_day;
				      $timr=$penal_hr."-".$penal_sec."-".$ams;
				      
				      $upd=execute("update doc_staff set doc_name='$doct',d_date='$penal',time='$timr',complaints='$txtPresenting',treatment='$txtTreatment',remarks='$txtRecommendations' where id='$fgb[id]'");
				      
				      //echo "Modified Successfully";
					 ?>
<script language="JavaScript" type="text/javascript">
alert("Modified Successfully");
</script>
<?php
 
				     }
				
				?>
</table>
<br>			
		<div>
        <center>
			<input type=submit name='gob' value='Go Back' class='bgbutton' onclick='cli()'>
			<input type=submit name='subn' value='Modify' class='bgbutton'>
            </center>
			</div>
	</form>


</body>

</html>
