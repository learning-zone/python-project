<html>
<head>
<?php
session_start();
include("../db.php");
$course=$_REQUEST['course'];
$sem=$_REQUEST['sem'];
$examid=$_REQUEST['examid'];
$studentid=$_REQUEST['studentid'];
$class_section=$_REQUEST['class_section'];
$stundetname=$_REQUEST['stundetname'];
$student_id=$_REQUEST['student_id'];	
$subject=$_REQUEST['subject'];	
$unit=$_REQUEST['unit'];	
$accyeardet=$_SESSION['AcademicYear'];
?>
</head>
<body>
<form name="frm" action="" method="post">
<?php
echo "
<input type='hidden' name='course' value='$course'>
<input type='hidden' name='sem' value='$sem'>
<input type='hidden' name='examid' value='$examid'>
<input type='hidden' name='studentid' value='$studentid'>
<input type='hidden' name='stundetname' value='$class_section'>
<input type='hidden' name='student_id' value='$student_id'>
<input type='hidden' name='subject' value='$subject'>
<input type='hidden' name='class_section_id' value='$class_section_id'>";
?>


<table align="center" width="70%" border="1" cellspacing="0" cellpadding="3">
  <?php
$studenname=mysql_query("select first_name,last_name from student_m where id='$student_id'");
$stundetname1=mysql_fetch_array($studenname);
  echo '

  <tr height="25">
<td align="center" colspan="5"  class="head" >Name : '.$stundetname1[0].'&nbsp;'.$stundetname1[1].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Id : '.$student_id.' </td>
  </tr>';

	$sqlbame=mysql_fetch_array(mysql_query("SELECT subject_id , subject_name,elective FROM subject_m where course_year_id='$sem' and subject_id='$subject'"));
		
		echo "<tr>
		<td nowrap width='75%' colspan='3' class='row2'>Subject Name&nbsp;:&nbsp;<strong>$sqlbame[1] </strong></td>
		
		</tr></table>";

	   $k=1;
		echo '<table align="center" width="70%" border="1" cellspacing="0" cellpadding="3">';
		$testss=mysql_query("SELECT skill, unit FROM msp_sub_skill  where sub='$subject'  and acc_year='$accyeardet' and exam_id='$examid' and status=1 order by unit");
		while($testss2=mysql_fetch_array($testss))
		{
			$unitnames=mysql_fetch_array(mysql_query("SELECT unit FROM msp_unit  where class='$sem' and exam_id='$examid' and sub='$subject'  and acc_year='$accyeardet' and status=1 and id='$testss2[1]'"));
			
			$r3=mysql_fetch_array(mysql_query("SELECT id,skill,mark FROM master_skills  where class='$sem' and exam_id='$examid' and id='$testss2[0]' order by posi"));
			
			if($unit!=$testss2['unit'])
			{
				?>
                <tr><td align="center" colspan="2" class="row2"><?=$unitnames[0]?></td>
                <td align="center" class="row2">Grade</td></tr>
                <tr>
                <?
			}
			?>
                
                <td nowrap width='3%' align='center' valign='top'><?=$k?></td>
                <td  valign='top'><?=$r3[1]?></td>
				<?
                $k++;
				
                $sql5=mysql_query("SELECT eval1, eval2,	eval3 FROM skill_grade where  student_id='$student_id' and	skill='$r3[0]' and acc_year='$accyeardet' and sub='$subject'");
                while($r5=mysql_fetch_array($sql5))
                
                {
					$eval1=$r5[0];
					$eval2=$r5[1];
                }
				
                ?>
			<td nowrap align='center'><?=$eval2?></td>
			</tr>
            
			<?
			
			$unit=$testss2['unit'];
			$eval2='';
		}

echo "</table>";
		
?>

</form>
</body>
</html>