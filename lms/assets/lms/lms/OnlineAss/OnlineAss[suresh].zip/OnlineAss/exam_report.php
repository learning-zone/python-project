<?php

	session_start();
	include("../db.php");
	
	if($_SESSION['per00']==1)
	{
		die("No Rights");
	}
	$examname=$_POST['examname'];
	$user=$_SESSION['user'];
	$academicYear=$_SESSION['AcademicYear'];
	$sem=$_SESSION['sem'];
	$studentdet=mysql_fetch_array(mysql_query("select id, class_section_id from student_m where student_id='$user'"));
	$class_section=$studentdet[1];
	$studentid=$studentdet[0];
?>
<html>
<head>
<script language="JavaScript" src="../js/gen_validatorv2.js" type="text/javascript"></script>
<script language="javascript" src="../js/cal2.js"></script>
<script language="javascript" src="../js/cal_conf2.js"></script>
<SCRIPT LANGUAGE="JavaScript">
function OpenWind3(URL, title,w,h)
{
	var left = (screen.width/2)-(w/2);
	var top = (screen.height/2)-(h/2);
var newWin = window.open (URL, title, '_blank, toolbar=no, location=no,directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left)
}

function reload()
{
	document.frm.action='exam_report.php';
	document.frm.submit();
}
</SCRIPT>
</head>
<body>

<form method="POST" name="frm">
<table align='center' cellpadding="0" class='forumline' width='40%' border="1" >
    <tr>
    	<td align="center" class="head" colspan="2">Students Review Sheet</td>
    </tr>
<tr>
    <td>&nbsp;Select Exam</td>
    <?php
    $accyear=$_SESSION['AcademicYear'];
    $rs_ec=execute("select id, descr  from exam_m where accyear='$accyear' and class='$sem' and sts=1");
    ?>
    <td>&nbsp;<select name='examname' onChange="reload()">
    <?
    echo "<option value=''>--Select--</option>";
    for($i=0;$i<rowcount($rs_ec);$i++)
    {
		$r_sec=fetcharray($rs_ec,$i);
		if($r_sec['id']==$examname)
			echo "<option value='$r_sec[id]' selected>$r_sec[descr]</option>";
		else
			echo "<option value='$r_sec[id]'>$r_sec[descr]</option>";
    }
    ?>
    </select>
    </td>
</tr>
</table>
<?php
	$subel=mysql_query(" select a.subject_id, a.subject_name, a.elective, a.sub_type from subject_m a,msp_unit b where a.course_year_id='$sem' and a.status=1 and a.sub_type!=3 and b.status=1 and b.sub=a.subject_id and b.acc_year='$academicYear' and b.exam_id='$examname' group by b.sub");

if(!$examname)
{
	die();
}
?>
<br>

		<table align='center' cellpadding="5" class='forumline' width='80%' border="1" >
	<tr height="10">
	  <td colspan=5 align='center' class='head'>Students Review Sheet</td></tr>
      <?
	  $unittest=mysql_query("SELECT unit,exam_id,sub FROM msp_unit where class='$sem' and sub='$subject' and  exam_id='$examname' and acc_year='$academicYear' and status=1");
					while($testids=mysql_fetch_array($unittest))
					{
	  ?>
	<tr >
		<td align="center" class="row3" width="5%" nowrap>Sl No.</td>
		<td align="center" class="row3" nowrap>Subject</td>
		<!--<td align="center" class="row3" nowrap>Subject type</td>-->
		<td align="center" class="row3" nowrap><?php echo $_SESSION['semname']; ?></td>
		<td align="center" class="row3" nowrap>Section</td>
		<td align="center" class="row3" nowrap>Chapter</td>
	</tr>
    <?
					}
	?>
		<?php
		$k=1;
		while($r=mysql_fetch_array($subel))
		{
			$subject=$r['subject_id'];
			$subject_type=$r['sub_type'];
			$flag=1;
			if($r['elective']=='Y')
			{
				$sql123=mysql_num_rows(mysql_query("select id from student_course  where stu_id='$studentid' and sub='$subject' and acc_year='$academicYear'"));
				if(!$sql123)
				$flag=0;
			}
			
			$subject_id_dis=mysql_fetch_row(mysql_query("select subject_name from subject_m where subject_id='$subject'"));
			$subject_type_dis=mysql_fetch_row(mysql_query("select subtype_name from subjecttype where subtype_id='$subject_type'"));
			$section_name=mysql_fetch_row(mysql_query("select section_name from class_section where id='$class_section'"));
			$course_year=mysql_fetch_row(mysql_query("select year_name from course_year where year_id='$sem'"));
			if($flag==1)
			{		
		?>	
                <tr >
                    <td align="center" valign="top" nowrap><?=$k?></td>
                    <td valign="top"  nowrap><?=$subject_id_dis[0]?></td>
                    <!--<td valign="top"  nowrap><?=$subject_type_dis[0]?></td>-->
                    <td valign="top"  align="center" nowrap><?=$course_year[0]?></td>
                    <td valign="top"  align="center" nowrap><?=$section_name[0]?></td>
                    <td valign="top"  align="center" width="10%" nowrap>

                <a href="javascript:void(0);" onClick ="OpenWind3('reports.php?sem=<?=$sem;?>&subject=<?=$subject;?>&examid=<?=$examname?>&student_id=<?=$studentid?>&class_section=<?=$class_section?>', 'OpenWind3',900,600)"><input type="button" class="bgbutton" name="new" value="View" /></a>
                 
                    </td>
                </tr>
                
                <?php
			    $k++;
			}
		}
		?>
</table>

		</form></body></html>
