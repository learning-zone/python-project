<html>
<head>
<?php
session_start();
include("../db.php");
$course=$_REQUEST['course'];
$sem=$_REQUEST['sem'];
$examid=$_REQUEST['examid'];
$studentid=$_REQUEST['studentid'];
$class_section=$_REQUEST['class_section'];
$stundetname=$_REQUEST['stundetname'];
$student_id=$_REQUEST['student_id'];	
$subject=$_REQUEST['subject'];	
$unit=$_REQUEST['unit'];	
$accyeardet=$_SESSION['AcademicYear'];
?>
</head>
<body>
<form name="frm" action="" method="post">
<?php
echo "
<input type='hidden' name='course' value='$course'>
<input type='hidden' name='sem' value='$sem'>
<input type='hidden' name='examid' value='$examid'>
<input type='hidden' name='studentid' value='$studentid'>
<input type='hidden' name='stundetname' value='$class_section'>
<input type='hidden' name='student_id' value='$student_id'>
<input type='hidden' name='subject' value='$subject'>
<input type='hidden' name='class_section_id' value='$class_section_id'>";
?>
<table align="center" width="70%" border="1" cellspacing="0" cellpadding="3">
<?php
$studenname=mysql_query("select first_name,last_name from student_m where id='$student_id'");
$stundetname1=mysql_fetch_array($studenname);
?>
<?
	$sqlbame=mysql_fetch_array(mysql_query("SELECT subject_id , subject_name,elective FROM subject_m where course_year_id='$sem' and subject_id='$subject'"));
	?>	
  <tr height="25">
<td align="center" colspan="5"  class="head" >Name :&nbsp;<?=$stundetname1[0]?>&nbsp;<?=$stundetname1[1]?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Id : <?=$student_id?>&nbsp;&nbsp;&nbsp;&nbsp;Subject Name&nbsp;:&nbsp;<?=$sqlbame[1]?></td>
  </tr>
	</table>
        
<table width="70%" align="center" class="forumline" border="1" cellspacing="0" cellpadding="3">
<?php
	$sql2=mysql_query("select id, exam_name, exam_sub_name,order_id from msp3_exam_sub_m where exam_id='$examid' and section='$class_section' and class='$sem' and status=1 and subject_id='$subject' order by order_id");
	while($r2=mysql_fetch_array($sql2))
	{
		$sql3=mysql_query("select id, exam_name, exam_sub_name,mark from msp3_exam_sub_sub_m where exam_id='$r2[0]' and status=1 order by order_id");
	
		 $num_rows = mysql_num_rows($sql3);
	echo "<tr>
    <td align='center' class='head' colspan='3'><b>$r2[1]</b></td>
	</tr>";
	echo "<tr>
    <td align='center' class='rowpic'><b>Exam Name</b></td>
    <td align='center' class='rowpic'><b>MAX Mark</b></td>
    <td align='center' class='rowpic'><b>Mark</b></td>
	</tr>";
		while($r3=mysql_fetch_array($sql3))
		{
				$studentmarks=mysql_fetch_array(mysql_query("select mark, status,maxmark from msp3_marks where class_section='$class_section' and student_id='$student_id' and subject_id='$subject' and sem_id='$examid' and int_id='$r2[0]' and tst_id='$r3[0]'"));

			?>
            <tr>
            <td align='' class=''>&nbsp;<b><?=$r3[1]?></b></td>
            <td align='center' class=''>&nbsp;<?=$r3[3]?></td>
            <td align='center' class=''>&nbsp;<?=$studentmarks[0]?></td>
            </tr>
		<?php
		}

	}
?>				
</table>
</form>
</body>
</html>