       <table width="100%"  align="center" class="forumline" border="1" cellspacing="0" cellpadding="0">
                           
 	
<?php
session_start();
include("../db.php");
$user=$_SESSION['user'];
$datedet=date("Y-m-d");
				$fieldname='username';
				$rdate=$datedet;
				$sql1=mysql_query("select course_admitted, course_yearsem, class_section_id from student_m where $fieldname='$user' and archive='N'");
				while($r1=mysql_fetch_array($sql1))
				{	
					$branch=$r1[0];
					$sem=$r1[1];
					$class_section_id=$r1[2];
				}
					$sql3=execute("select subject_id, subject_name from subject_m where   course_year_id='$sem' and status='1' order by sub_pre");
					while($r3=mysql_fetch_array($sql3))
					{		
						$sql24=mysql_query("select topic , home_work from teacher_lesson_plan where subj='$r3[0]' and  r_date='$rdate' and sec='$class_section_id'");
						while($r4=mysql_fetch_array($sql24))
						{
							echo "<tr height='20'>
									<td nowrap>$r3[1]</td>
									<td align='justify'  >$r4[1]</td>";
									$reso=mysql_fetch_row(mysql_query("select reso from master_lesson_plan where id='$r4[0]'"));

									echo "<td nowrap>";
									if($reso[0]!='')
									{
										echo "<a href='$reso[0]'>
									Download</a>";
									}
									echo "</td>
									</tr>";
						}	
							
					}
				
			
			?> 
             <tr >
                <td align="center" class="">lllllllllllllllllllkal</td>
                <td align="center" class=""></td>
                <td align="center" class=""></td>
            </tr>
         </table>



<script src="../SpryAssets/SpryAccordion.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryAccordion.css" rel="stylesheet" type="text/css" />
<div id="Accordion1" class="Accordion" tabindex="1">
  <?php
  for($i=1;$i<10;$i++)
  {
  ?>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">Label <?=$i?></div>
    <div class="AccordionPanelContent">Content <?=$i?></div>
  </div>
  <?php
  }
  ?>
</div>
<script type="text/javascript">
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
</script>
