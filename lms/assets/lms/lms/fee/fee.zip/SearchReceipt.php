<?php
session_start();
include("../db.php");
if($_POST)
{
	$branch=$_POST['branch'];
	$sem=$_POST['sem'];  
	$intl=$_POST['intl'];
	$reciptid=$_POST['reciptid'];
}
else
{
	$branch=$_SESSION['branch'];
	$sem=$_SESSION['sem'];
}
?>

<html>
<head>
<script language="javascript" src="cal2.js"></script>
<script language="javascript" src="cal_conf2.js"></script>

<script LANGUAGE="JavaScript">

function frm_reload()
{
	document.frm.action='SearchReceipt.php';
	document.frm.submit();
} 
function OpenWind(k)
{
	var finalVar;
	finalVar=k;
	window.open(finalVar,'Stud','height=700,width=1000,status=no,toolbar=no,scrollbars=yes,menubar=no,location=no');
}

</script>
</head>
<body>
<form method='post' name="frm" >
<table class='forumline' align='center' width='90%'><tr><td Class="Head" colspan='5' align='center'>Search Student Detials</td></tr>
<tr>
<td>&nbsp;&nbsp;<?php echo $_SESSION['branchname']; ?></td>
	<td>
		<select name="branch" onchange='frm_reload()'>
		<option value="0">---- Select ----</option>
			<?php
				$sql="select course_id,coursename from course_m order by head_id,coursename";
				$rs=execute($sql);
				for($i=0;$i<rowcount($rs);$i++)
				{
				  $r=mysql_fetch_array($rs);

					if($branch==$r[course_id])
					{
						?>
						<option value="<?=$r[course_id]?>" selected><?php echo $r[coursename] ?></option>
						<?php
					}
					else
					{
						?>
						<option value="<?php echo $r[course_id] ?>"><?=$r[coursename]?></option>
						<?php
					}
				}
			?>
		</select>
	</td>
		<td>&nbsp;&nbsp;<?php echo $_SESSION['semname']; ?></td>
	<td><select name="sem" onchange='frm_reload()'>
		<option value='0'>------ Select -----</option>
		<?php
			$rs1=execute("select * from course_m where course_id=$branch");
			$hdid=fetcharray($rs1);
			$hd_id=$hdid[head_id];
			$rs=execute("SELECT year_name,year_id FROM course_year where head_id='$hd_id'");
			while($r=fetcharray($rs))
			{
				if($sem==$r[year_id])
				{
					echo "<option value='$r[year_id]' selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $r[year_name]</option>";
				}
				else
				{
					echo "<option value='$r[year_id]'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $r[year_name]</option>";
				}
			}
		?>
		</select>
	</td></tr>
  <tr>
	<td>&nbsp;&nbsp;Receipt Number</td>
	<td align=''><input type='text' name='reciptid' value=""></td>
	<td nowrap>&nbsp;&nbsp;No Of Installment </td>
		<td align="left"><select name='intl' OnChange=go()>
        		<option value=''>-- Select --</option>
				<?php
                for($k=1;$k<=12;$k++)
				{
				if($k==$intl)
                echo"<option value='$k' selected>$k</option>";
				else
				echo"<option value='$k'>$k</option>";
				}
                ?>  
		</select>
        </td>
  </tr>
    
</table><br>
<div align='center'>
<input type="submit" class='bgbutton' value="Submit" name="studdet">
</div><br>
<?php
if(!$intl)
die();

$sql="select a.student_id, a.first_name, a.last_name, a.admission_type, a.course_admitted, a.course_yearsem, a.academic_year, a.class_section_id ,b.id, b.currencyType, b.amount , b.clearedDate, b.amountCleared, b.receipt from student_m a , fee_m_collect b where a.archive='N' and a.id=b.studentId and a.academic_year=b.accYear and b.installmentId='$intl' and  b.status=1  ";
	if($reciptid)
	{
		$sql.=" and b.receipt='$reciptid'";
	}
	else
	{
		if($branch!=0)
		{
			$sql.=" and a.course_admitted=$branch";
		}
		if($sem!=0)
		{
			$sql.=" and a.course_yearsem=$sem";
		}
	}
	$sql.=" order by a.course_admitted, a.course_yearsem, a.class_section_id, a.first_name";
	$rs=execute($sql);
	if(rowcount($rs)==0)
	{
		echo "<b>No Student Records Found !!</b>";
		die();
	}
	
	 $adate=date("d/m/Y");

?>
<table border=1 class=forumline align=center width='90%' cellspacing='0' cellpadding='1'>
<tr><td align='center' class='head' colspan='8'>Student Details 
</td>
</tr>
<tr height='30'>
<td height="28" align='center' nowrap Class="rowpic">Sl No</td>
<td Class="rowpic" align='center' nowrap>Student ID</td>
<td Class="rowpic" align='center' nowrap>Student Name</td>
<td Class="rowpic" align='center' nowrap>Section</td>
<td Class="rowpic" align='center' nowrap>Receipt No</td>
<td Class="rowpic" align='center' nowrap>Received</td>
<td Class="rowpic" align='center' nowrap>Reconciliation Date and Amount</td>
</tr>
<?php
$sno=1;
$fg=0;
for($i=0;$i<rowcount($rs);$i++)
{
	$r=fetcharray($rs);
	$cyr=$r[academic_year];
	$currency=$r[currencyType];
	$currencydes=mysql_fetch_row(mysql_query("select code from fee_m_currency_code where id='$currency'"));
	$currencydes1=mysql_fetch_row(mysql_query("select code from fee_m_currency_code where id=1"));
		$fg=1;
		if($sno<10)
			$sno="0".$sno;
		echo "<tr height='23'><td align='center'>$sno</td>";
		?><td align="center"><A HREF="javascript:OpenWind('cancel.php?recordid=<?php echo $r[id]?>&course=<?php echo $r[course_admitted] ?>&sem=<?php echo $r[course_yearsem] ?>');"><?php echo $r[student_id] ?></A>		
		  </td>
		<td>&nbsp;&nbsp;&nbsp;<?=$r[first_name]?>&nbsp;<?php echo $r[last_name]?></td>
		<?php
		$cname=fetcharray(execute("select year_name from course_year where year_id='$r[course_yearsem]'"));
		$secname=fetcharray(execute("select section_name from class_section where id='$r[class_section_id]'"));
		echo "<td align='center'>$cname[0] / $secname[0]</td>";
		echo "<td align='center'>$r[receipt]</td>";
		echo "<td align='center'>$r[amount] $currencydes[0]</td>";
		echo "<td align='right'>$r[amountCleared] $currencydes1[0] ( $r[clearedDate] )</td></tr>";
		
		$sno++;
	
}
?>
</table>

</form>
</body>
</html>