<html>
<head>
<?php
session_start();
include("../db.php");
if($_POST)
{
	$branch=$_POST['branch'];
	$sem=$_POST['sem'];
	$student_id=$_POST['student_id'];
	$studfname=$_POST['studfname'];
}
else
{
	$branch=$_SESSION['branch'];
	$sem=$_SESSION['sem'];
}
?>

<script LANGUAGE="JavaScript">
function send()
{
	if(document.frm.studfname.value=='' && document.frm.student_id.value=='' && document.frm.sem.value==0)
	{
		alert ("Enter Student ID or Name or Semester Details ... ");
		return false;
	}
	document.frm.action='fee_rec.php';
	document.frm.submit();
}
function frm_reload()
{
	document.frm.action='fee_rec.php';
	document.frm.submit();
} 
function OpenWind(k)
{
	var finalVar;
	finalVar=k;
	window.open(finalVar,'Stud','height=700,width=1000,status=no,toolbar=no,scrollbars=yes,menubar=no,location=no');
}

</script>
</head>
<body>
<form method='post' action="modify_stud_det.php" name="frm" >

<table class='forumline' align='center' width='90%'><tr><td Class="Head" colspan='5' align='center'>Search Student Detials</td></tr>
<tr>
<td>&nbsp;&nbsp;<?php echo $_SESSION['branchname']; ?></td>
	<td>
		<select name="branch" onchange='frm_reload()'>
		<option value="0">---- Select ----</option>
			<?php
				$sql="select course_id,coursename from course_m order by head_id,coursename";
				$rs=execute($sql);
				for($i=0;$i<rowcount($rs);$i++)
				{
				  $r=mysql_fetch_array($rs);

					if($branch==$r[course_id])
					{
						?>
						<option value="<?=$r[course_id]?>" selected><?php echo $r[coursename] ?></option>
						<?php
					}
					else
					{
						?>
						<option value="<?php echo $r[course_id] ?>"><?=$r[coursename]?></option>
						<?php
					}
				}
			?>
		</select>
	</td>
		<td>&nbsp;&nbsp;<?php echo $_SESSION['semname']; ?></td>
	<td><select name="sem" onchange='frm_reload()'>
		<option value='0'>------ Select -----</option>
		<?php
			$rs1=execute("select * from course_m where course_id=$branch");
			$hdid=fetcharray($rs1);
			$hd_id=$hdid[head_id];
			$rs=execute("SELECT year_name,year_id FROM course_year where head_id='$hd_id'");
			while($r=fetcharray($rs))
			{
				if($sem==$r[year_id])
				{
					echo "<option value='$r[year_id]' selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $r[year_name]</option>";
				}
				else
				{
					echo "<option value='$r[year_id]'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $r[year_name]</option>";
				}
			}
		?>
		</select>
	</td></tr>
	<tr>
	<td>&nbsp;&nbsp;Student ID</td>
	<td align=''><input type='text' name='student_id' value=""></td>
	<td>&nbsp;&nbsp;Student Name</td>
	<td align=''><input type='text' name='studfname' value=""></td></tr>
</table><br>
<div align='center'>
<td ><input type="submit" class='bgbutton' value="Submit" name="studdet" OnClick=" return send()"></td>
</div><br>
<?php
	$sql="select id,student_id,first_name,last_name,admission_type,course_admitted,course_yearsem,academic_year,class_section_id from student_m where archive='N'";
	if($branch!=0)
	{
	$sql.=" and course_admitted=$branch";
	}
	if($sem!=0)
	{
	$sql.=" and course_yearsem=$sem";
	}
	if($studfname!='')
	{
	 $sql.=" and first_name like '$studfname%'";
	}
	if($student_id!='')
	{
		$sql.=" and student_id='$student_id'";
	}
	$sql.=" order by course_admitted,course_yearsem,class_section_id,first_name";
	$rs=execute($sql);
	if(rowcount($rs)==0)
	{
		echo "<b>No Student Records Found !!</b>";
		die();
	}
?>
<table border=1 class=forumline align=center width='90%' cellspacing='0' cellpadding='1'>
<tr><td align='center' class='head' colspan='4'>Student Details</td>
</tr>
<tr height='30'>
<td Class="rowpic" align='center' nowrap>Sl No</td>
<td Class="rowpic" align='center' nowrap>Student ID</td>
<td Class="rowpic" align='center' nowrap>Student Name</td>
<td Class="rowpic" align='center' nowrap>Section</td></tr>
<?php
$sno=1;
$fg=0;
for($i=0;$i<rowcount($rs);$i++)
{
	$r=fetcharray($rs);
	$cyr=$r[academic_year];
	$chkstud=execute("select id from fee_master where studid='$r[id]' and status=0 and pid='$r[course_admitted]' and sid='$r[course_yearsem]' and accyr='$cyr' and tmid='$tmid'");
	if(rowcount($chkstud)==0)
	{
		$fg=1;
		if($sno<10)
			$sno="0".$sno;
		echo "<tr height='23'><td align='center'>$sno</td>";
		?>
		<td align="center">
		   <A HREF="javascript:OpenWind('fee_add.php?stud_id=<?php echo $r[id]?>&course=<?php echo $r[course_admitted] ?>&sem=<?php echo $r[course_yearsem] ?>&adm_id=<?php echo $r[admission_type] ?>&stud_yr=<?php echo $r[academic_year]?>');"><?php echo $r[student_id] ?></A>		
		  </td>
		<td>&nbsp;&nbsp;&nbsp;<?=$r[first_name]?>&nbsp;<?php echo $r[last_name]?></td>
		<?php
		$cname=fetcharray(execute("select year_name from course_year where year_id='$r[course_yearsem]'"));
		$secname=fetcharray(execute("select section_name from class_section where id='$r[class_section_id]'"));
		echo "<td align='center'>$cname[0] / $secname[0]</td></tr>";
		$sno++;
	}
}
if($fg==0)
	die("<div><font color='brown'><b>First time fee receipt already generated for all students. Use Generate Addl Fee Receipt Link.</b></font></div>");	
?>
</table>

</form>
</body>
</html>