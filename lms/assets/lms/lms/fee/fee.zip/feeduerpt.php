<html>
<head>
<?php
session_start();
include("../db.php");
?>
<SCRIPT LANGUAGE="JavaScript">
function OpenWind(k)
{
	var finalVar;
	finalVar=k;
	window.open(finalVar,'Stud','height=600,width=750,status=yes,toolbar=no,scrollbars=yes,menubar=no,location=no');
}
function prnfee()
{
	prn.style.display = "none";
	window.print(this.form);
	prn.style.display = "";
}
</script>
</head>
<body>
<form name='frm' method='post'>
<?php
$sql=execute("select distinct(a.pid),a.sid,b.course_abbr,c.year_name from fee_master a,course_m b,course_year c where a.pstatus=1 and a.status=0 and a.pid=b.course_id and a.sid=c.year_id order by a.pid,a.sid");

if(rowcount($sql)>0)
{
	?>
	<table class='forumline' border=1 align=center>
	<tr height="30"><td align=center class=head colspan=4><font size='3'>FEE DUE REPORT</font></TD></TR>
	<tr height="30"><td align=center>Sl.No</td><td align=center>Program</td><td align=center>Semester/Year</td><td align=center>Due Amount</td></tr>
	<?php
	$sno=1;
	$ttlamt=0;
	while($r=fetcharray($sql))
	{
		$sql1=fetcharray(execute("select sum(balamt) from fee_master where pid='$r[0]' and sid='$r[1]' and pstatus=1 and status=0"));
		$amt=number_format($sql1[0],2);
		if($sno<10)
			$sno="0".$sno;
		echo "<tr height='30'><td align='center'>$sno</td>";
		echo "<td>&nbsp;&nbsp;$r[course_abbr]</td>";
		echo "<td>&nbsp;&nbsp;$r[year_name]</td>";
		?>
		<td align='right'><a href="javascript:OpenWind('duerpt1.php?pid=<?=$r[0]?>&sid=<?=$r[1]?>')"><?=$amt?></td></tr>
		<?php
		$sno++;
		$ttlamt+=$sql1[0];
	}
	$ttlamt=number_format($ttlamt,2);
	?>
	<tr><td align='right' colspan='3'>Total Amount&nbsp;&nbsp;</td><td align='right'><font color='blue'><b><?=$ttlamt?></b></font></td></tr>
	</table><br>
	<div id="prn" align="center"><input type="button" name="prnfeest" value="PRINT" class="bgbutton" onClick="prnfee()"></div>
	<?php
}
else
	echo "<b>No Fee Due Report ...</b>";
?>
</form>
</body>
</html>