<html>
<?php
session_start();
include("../db.php");
if($_POST)
{
	$course=$_POST['course'];
	$year1=$_POST['year1'];
	$feehead=$_POST['feehead'];
	$accyear=$_POST['accyear'];
}
else
{
	$course=$_SESSION['branch'];
	$year1=$_SESSION['sem'];	
}
?>
<head>
<script language='javascript'>
function reloadMe()
{
	document.frm.action="dmdfee.php";
	document.frm.submit();
}
function reloadMe1()
{
	if(document.frm.year1.value=='0' || document.frm.feehead.value=='0' || document.frm.accyear.value=='0')
	{		
		alert ("Select all details...");
		return false;	
	}
	document.frm.action="dmdfee1.php";
	document.frm.submit();
}
</script>
</head>
<body>
<form name="frm" method="post" action="dmdfee.php">
<table class='forumline' align='center' border="0" width='80%'>
<tr><td Class="head" align='center' colspan=4 >Fee Structure</td></tr>
	<tr height='25'>
		<td nowrap>&nbsp;&nbsp;<?=$_SESSION['branchname']?></td>
	 <td>
	 <select name="course" onChange="reloadMe()">
	 <option value='0'>Select </option>
	 <?php
	 	$sql="select * from course_m where status=1";
	 	$rs=execute($sql) or die(error_description());
	 	for($i=0;$i<rowcount($rs);$i++)
	 	{
	 		$r1=fetchrow($rs);
	  		if($course==$r1[0])
	 		{
				?>
	 			<option value="<?php echo $r1[0]?>" selected><?php echo $r1[1]?></option>
				<?php
	 		}
	 		else
	 		{
				?>
	 			<option value="<?php echo $r1[0]?>"><?php echo $r1[1]?></option>
				<?php
	 		}
	 	}
	 ?>
	 </select>
	</td>
	<td nowrap>&nbsp;&nbsp;<?=$_SESSION['semname']?></td>
	 <td>
	 <select name="year1">
	 <option value='0'>-- Select --</option>
	 <?php
		$sq=fetcharray(execute("select head_id from course_m where course_id='$course'"));
	    if($course==1)
			$sql=execute("select year_id,year_name from course_year where head_id='$sq[0]' and status=1 and year_id in(1,3)");
		else
			$sql=execute("select year_id,year_name from course_year where head_id='$sq[0]' and status=1 and year_id in(5,8)");
		for($i=1;$i<=rowcount($sql);$i++)
		{
			$r=fetcharray($sql);
			if($year1==$r[0])
			{
				echo "<option value='$r[0]' selected>$r[1]</option>";
			}
			else
			{
				echo "<option value='$r[0]'>$r[1]</option>";
			}
		}
		?>
	 </select>
	</td></tr>
	<tr height='25'><td nowrap>&nbsp;&nbsp;Admission Type</td>
	 <td><select name="feehead">
	 <option value='0'>Select</option>
	 <?php
	 	$sql2="select * from admission ";
	 	$rs2=execute($sql2) or die(error_description());
	 	for($i=0;$i<rowcount($rs2);$i++)
	 	{
	 		$r2=fetchrow($rs2);
	  		if($feehead==$r2[0])
	 		{
				?>
	 			<option value="<?php echo $r2[0]?>" selected><?php echo $r2[1]?></option>
				<?php
	 		}
	 		else
	 		{
				?>
	 			<option value="<?php echo $r2[0]?>"><?php echo $r2[1]?></option>
				<?php
	 		}
	 	}
	 ?>
	 </select>
</td><td nowrap>&nbsp;&nbsp;Academic Year</td>
<td><select name="accyear">
<option value='0'>--- Select ----</option>
<?php
$cyear=date("Y");
$accyear=$curyr1;
$fmyr=$cyear-5;
$toyr=$cyear+1;
for($i=$fmyr;$i<=$toyr;$i++)
{
	$y=$i+1;
	if($accyear==$i)
		echo "<option value=$i selected>$i-$y</option>";
	else
		echo "<option value=$i>$i-$y</option>";
}
?>
</select></td></tr>
</table>

<br>
<br> <div  align='center'><input type='button'  name='src' class="bgbutton" value='View' onClick="reloadMe1()">
</div>
</form>
</html>