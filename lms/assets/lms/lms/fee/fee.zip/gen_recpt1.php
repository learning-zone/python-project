<html>
<head>
<title>Fee Receipt</title>
<?php
session_start();
include("../db1.php");

include("numbers-words.php");
//number_to_words($ttlamt)

	$course=$_POST['course'];	//branch name
	$sem=$_POST['sem'];		//semister		
	$adm_id=$_POST['adm_id'];	//admision ID
	$stud_id=$_POST['stud_id'];		//student row id
	$stud_yr=$_POST['stud_yr'];		//accadamic year
	$oexeamt=$_POST['oexeamt'];		//old exxcess payment
	$oldbalamt=$_POST['oldbalamt'];		// old balance payment 
	$currency=$_POST['currencyType'];		//currency type
	$installmentId=$_POST['installmentId'];		//installmentId 
	$fine=round($_POST['fine'],2);		//fine
	$uid=$_POST['uid'];
	$currencydes=mysql_fetch_row(mysql_query("select code from fee_m_currency_code where id='$currency'"));

	
	$pydt=$_POST['pydt'];	
	$pymt=$_POST['pymt'];
	$pyyr=$_POST['pyyr'];
	$pamentdate="$pyyr-$pymt-$pydt";		//Payment Date
	$pamentdatedisplay="$pydt-$pymt-$pyyr";		//Payment Date display
		
	$paymenttype=$_POST['paymenttype'];		//Mode of Payment
	$bname=$_POST['bname'];		//Bank Name
	$bdet=$_POST['bdet'];		//Branch Details
	$ddno=$_POST['ddno'];		//DD or Cheque No.
	
	$pdt=$_POST['pdt'];
	$pmt=$_POST['pmt'];
	$pyr=$_POST['pyr'];
	$chequeDate="$pyr-$pmt-$pdt";		//DD/Cheque Date
	$chequeDatedis="$pdt-$pmt-$pyr";		//DD/Cheque Date
	
	$amt=$_POST['amt'];  	//total paid
	$remk=$_POST['remk'];		//remarks
	
	$feeType=$_POST['feeType'];
	$feeRecVal=$_POST['feeRecVal'];
	
	$receipt='dd';


$sql=fetcharray(execute("select id from `fee_m_collect` order by id  DESC limit 1"));
$docid=$sql[0]+1;
$docid="CS/FR/".$docid;

//to check duplicate entry
$validation=mysql_query("select id from `fee_m_collect` where `accYear`='$stud_yr' and `studentId`='$stud_id' and  `admissionCat`='$adm_id' and `installmentId`='$installmentId' and status=1");
if(mysql_num_rows($validation))
{
	$sql=fetcharray($validation);
	$docid=$sql[0];
	$docid="CS/FR/".$docid;

}
?>
<script language="javascript" type="text/javascript">
function dataprint()
{
	prn.style.display = "none";
	window.print(this.form);
}
function clswnd()
{
	window.close();
}
function showKeyCode(e)
{
	var keycode = e;
	if(keycode == 116)
	{
		event.keyCode = 0;
		event.returnValue = false;
		return false;
	}
}
</script>
</head>
<body oncontextmenu="return false;" onkeydown='showKeyCode(event.keyCode)'>
<form name="frm" method='post'>
<?php
$dddate=$pydt."-".$pymt."-".$pyyr;

$dddate1=$pyyr."-".$pymt."-".$pydt;
$dddate2=$pdt."-".$pmt."-".$pyr;
$dddate3=$pyr."-".$pmt."-".$pdt;

$cdate1=date("d-m-Y");
$tdt=date("Y-m-d");
$cyr=$stud_yr;

$sql=fetcharray(execute("select first_name,last_name,student_id,course_yearsem,admission_id from student_m where id=$stud_id"));
$sql1=fetcharray(execute("select course_abbr from course_m where course_id=$course"));
$sql2=fetcharray(execute("select year_name from course_year where year_id='$sql[course_yearsem]'"));
if($paymenttype==1)
	$modepay="Cash";
elseif($paymenttype==2)
	$modepay="Demand Draft";
elseif($paymenttype==3)
	$modepay="Bank Cheque";

$userid=fetcharray(execute("select id from users where username='$user'"));

?>
<table align="center" width="100%" cellpadding="20" cellspacing="20" border="0">
<tr>
	<td align="center" width="50%">
    <!--office coppy code starts-->
		<table align="center" width="100%" cellpadding="0" cellspacing="0" border="1" >
			<tr>
            	<td nowrap>
     				<img src="../images/logo.PNG" border="0" height="100" width="85">
                </td>
                <td valign="middle" align="center" >
     			   <?=$_SESSION['SchoolName']?><br>
                   <?=$_SESSION['SchoolAddress']?>
                </td>
            </tr>
            <tr>
            	<td colspan="2">
                    <table border="0" width="100%">
                    <tr>
                        <td align="right" colspan="2">
                        <u>Office copy</u><br>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2">
                        <u><strong>FEE RECEIPT</strong></u><br><br>
                        </td>
                    </tr>
                    
                	<tr>
                    	<td width="50%" nowrap>
                        Receipt No : <?=$docid?>
                        </td>
                    	<td width="50%" nowrap>
                        Date : <?=$pamentdatedisplay?>
                        </td>
                    </tr>    
                	<tr>
                    	<td colspan="2" nowrap>
                        Name : <?=$sql[0].' '.$sql[1]?>
                        </td>
                    </tr>    
                	<tr>
                    	<td width="50%" nowrap>
                        <?=$_SESSION['semname']?> : <?=$sql2[0]?>
                        </td>
                    	<td width="50%" nowrap>
                        Admn No : <?=$sql[2]?>
                        </td>
                    </tr>    
                	<tr>
                    	<td width="50%" nowrap>
                        Installment : <?=$installmentId?>
                        </td>
                    	<td width="50%" nowrap>
                        Payment Mode : <?=$modepay?>
                        </td>
                    </tr>    
                </table>
                </td>
            </tr>           
        </table> 
        <table align="center" border="1" cellpadding="5" cellspacing="0" width="100%">
          <tr>
            <td align="center" width="10%" nowrap>Sl No</td>
            <td  align="center">Particulars</td>
            <td  align="center" width="20%">Amount</td>
          </tr>
		<?php
        $i=1;
        $sql44= mysql_query("SELECT fee_id,fee_name, ftype FROM fee_type WHERE status=1 ORDER BY fee_id");
        while($r=mysql_fetch_array($sql44))
        {
			$flag=1;
			if($r[2]==1)
			{
				$feests=mysql_fetch_row(mysql_query("select cleared from `fee_m_head_total` where feeHead='$r[0]' and studentId='$stud_id' and status=1"));
				if($feests[0]==1)
				$flag=0;

			}
			if($flag)
			{
			
				$feeval=mysql_fetch_row(mysql_query("select amount from  fee_m_descrption_val where uid='$uid' and fee_head='$r[0]' and inst_id='$installmentId'"));
				if($feeval[0])
				$val=$feeval[0];
				else
				$val=0;
				
				$sumval=$sumval+$val;
				if($val)
				{	
					echo "<tr>
					<td align='center' width='10%' nowrap>$i</td>
					<td  align='left' nowrap>&nbsp;&nbsp;$r[1]</td>
					<td  align='right' nowrap>&nbsp;&nbsp;$val $currencydes[0]&nbsp;&nbsp;</td>
					</tr>";
					$i++;
				}
			}
        }
		if($fine)
		{
		?> 
          <tr>
            <td colspan="2"  align="right">Fine Amount&nbsp;&nbsp;</td>
            <td  align="right" nowrap>&nbsp;&nbsp;<?=$fine.' '.$currencydes[0]?>&nbsp;&nbsp;</td>
          </tr>
        <?php
		}
		?>  
           <tr>
            <td colspan="2"  align="right"><strong>&nbsp;Total&nbsp;&nbsp;</strong></td>
            <td  align="right" nowrap>&nbsp;&nbsp;<?=$amt.' '.$currencydes[0]?>&nbsp;&nbsp;</td>
          </tr>
          
          <tr>
            <td colspan="3"  align="justify" nowrap>
            	<br>
                &nbsp;&nbsp;<strong>Remarks :</strong> &nbsp;&nbsp; <?=$remk?>
                <br><br>
                &nbsp;&nbsp;<strong>Amount in words :</strong> 
                <div align="center"><?=number_to_words($amt)?> only</div>
                <br><br>
                <div align="right">Signature&nbsp;&nbsp;</div>
                
                &nbsp;&nbsp; 
            </td>
          </tr>
                  
        </table>  
   <!--office coppy code ends-->
    <td align="center" width="50%">
    
        <!--student coppy code starts-->
		<table align="center" width="100%" cellpadding="0" cellspacing="0" border="1" >
			<tr>
            	<td nowrap>
     				<img src="../images/logo.PNG" border="0" height="100" width="85">
                </td>
                <td valign="middle" align="center" >
     			   <?=$_SESSION['SchoolName']?><br>
                   <?=$_SESSION['SchoolAddress']?>
                </td>
            </tr>
            <tr>
            	<td colspan="2">
                    <table border="0" width="100%">
                    <tr>
                        <td align="right" colspan="2">
                        <u>Student copy</u><br>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2">
                        <u><strong>FEE RECEIPT</strong></u><br><br>
                        </td>
                    </tr>
                    
                	<tr>
                    	<td width="50%" nowrap>
                        Receipt No : <?=$docid?>
                        </td>
                    	<td width="50%" nowrap>
                        Date : <?=$pamentdatedisplay?>
                        </td>
                    </tr>    
                	<tr>
                    	<td colspan="2" nowrap>
                        Name : <?=$sql[0].' '.$sql[1]?>
                        </td>
                    </tr>    
                	<tr>
                    	<td width="50%" nowrap>
                        <?=$_SESSION['semname']?> : <?=$sql2[0]?>
                        </td>
                    	<td width="50%" nowrap>
                        Admn No : <?=$sql[2]?>
                        </td>
                    </tr>    
                	<tr>
                    	<td width="50%" nowrap>
                        Installment : <?=$installmentId?>
                        </td>
                    	<td width="50%" nowrap>
                        Payment Mode : <?=$modepay?>
                        </td>
                    </tr>    
                </table>
                </td>
            </tr>           
        </table> 
       <table align="center" border="1" cellpadding="5" cellspacing="0" width="100%">
          <tr>
            <td align="center" width="10%" nowrap>Sl No</td>
            <td  align="center" nowrap>Particulars</td>
            <td  align="center" width="20%" nowrap>Amount</td>
          </tr>
		<?php
        $i=1;
        $sql44= mysql_query("SELECT fee_id,fee_name, ftype FROM fee_type WHERE status=1 ORDER BY fee_id");
        while($r=mysql_fetch_array($sql44))
        {
			$flag=1;
			if($r[2]==1)
			{
				$feests=mysql_fetch_row(mysql_query("select cleared from `fee_m_head_total` where feeHead='$r[0]' and studentId='$stud_id' and status=1"));
				if($feests[0]==1)
				$flag=0;

			}
			if($flag)
			{
			
				$feeval=mysql_fetch_row(mysql_query("select amount from  fee_m_descrption_val where uid='$uid' and fee_head='$r[0]' and inst_id='$installmentId'"));
				if($feeval[0])
				$val=$feeval[0];
				else
				$val=0;
				
				$sumval=$sumval+$val;
				if($val)
				{	
					echo "<tr>
					<td align='center' width='10%' nowrap>$i</td>
					<td  align='left' nowrap>&nbsp;&nbsp;$r[1]</td>
					<td  align='right' nowrap>&nbsp;&nbsp;$val $currencydes[0]&nbsp;&nbsp;</td>
					</tr>";
					$i++;
				}
			}
        }
		if($fine)
		{
		?> 
          <tr>
            <td colspan="2"  align="right">Fine Amount&nbsp;&nbsp;</td>
            <td  align="right" nowrap>&nbsp;&nbsp;<?=$fine.' '.$currencydes[0]?>&nbsp;&nbsp;</td>
          </tr>
        <?php
		}
		?>  
           <tr>
            <td colspan="2"  align="right"><strong>&nbsp;Total&nbsp;&nbsp;</strong></td>
            <td  align="right">&nbsp;&nbsp;<?=$amt.' '.$currencydes[0]?>&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td colspan="3"  align="justify">
            	<br>
                &nbsp;&nbsp;<strong>Remarks :</strong> &nbsp;&nbsp; <?=$remk?>
                <br><br>
                &nbsp;&nbsp;<strong>Amount in words :</strong> 
                <div align="center"><?=number_to_words($amt)?> only</div>
                <br><br>
                <div align="right">Signature&nbsp;&nbsp;</div>
                
                &nbsp;&nbsp; 
            </td>
          </tr>
                  
        </table>  
   <!--Student coppy code ends-->
    </td>
</tr>
</table>

</form>
<div id="prn" align='center'><Input Type="button" Value=" Print " class='bgbutton' onClick="dataprint()">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<Input Type="button" Value=" Send SMS " class='bgbutton' onClick="">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<Input Type="button" Value=" Send Mail " class='bgbutton' onClick="">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name='clse' value=" Close " class='bgbutton' onClick="clswnd()"></div>
<?php
$sql=fetcharray(execute("select id from `fee_m_collect` order by id  DESC limit 1"));
$docid=$sql[0]+1;
$docid="CS/FR/".$docid;

//to check duplicate entry
$validation=mysql_query("select id from `fee_m_collect` where `accYear`='$stud_yr' and `studentId`='$stud_id' and  `admissionCat`='$adm_id' and `installmentId`='$installmentId' and status=1");
if(!mysql_num_rows($validation))
{
	$feestBlock=mysql_fetch_row(mysql_query("select no_of_student from `fee_m_descrption` where uid='$uid'"));
	$feestBlock1=$feestBlock[0]+1;
	mysql_query("update `fee_m_descrption` set no_of_student='$feestBlock1' where uid='$uid' ");
	
	$feestBlockInst=mysql_fetch_row(mysql_query("select no_of_student from `fee_m_descrption_inst_total` where uid='$uid' and inst_id='$installmentId'"));
	$feestBlockInst1=$feestBlockInst[0]+1;
	
	mysql_query("update `fee_m_descrption_inst_total` set no_of_student='$feestBlockInst1' where uid='$uid' and inst_id='$installmentId'");
	
	//to check if currancy type is native currancy and payment mode is cash this ll update the details
	if($currency==1 and $paymenttype==1)
	{
		$clearedDate=$pamentdate;
		$amountCleared=$amt;
	}
	
	$sql4="INSERT INTO `fee_m_collect` ( `accYear`, `studentId`, `admissionCat`, `currencyType`, `installmentId`, `amount`, `fine`, `paymentDate`, `modeOfPament`, `bankName`, `bankDetails`, `ddChequeNo`, `ddChequeDate`,  `remarks`, `receipt`, `status`,`clearedDate`,`amountCleared`) VALUES ('$stud_yr', '$stud_id', '$adm_id', '$currency', '$installmentId', '$amt', '$fine', '$pamentdate', '$paymenttype', '$bname', '".addslashes($bdet)."', '".addslashes($ddno)."', '$chequeDate', '".addslashes($remk)."', '".addslashes($docid)."', '1','$clearedDate','$amountCleared')";
	
	mysql_query($sql4);

	for($i=0;$i<sizeof($feeRecVal);$i++)
	{
		$feeType1=$feeType[$i];
		$feeRecVal1=$feeRecVal[$i];

		//this code ll insert the  value each fee head vice data
		
		mysql_query("INSERT INTO `fee_m_head_inst_collected` (`uid`, `accYear`, `instId`, `receipt`, `studentId`, `feeHead`, `totalAmount`, `totalConverted`, `currency`, `status`) VALUES ('$uid', '$stud_yr', '$installmentId', '$docid', '$stud_id', '$feeType1', '$feeRecVal1', '', '$currencyType', '1')");
		
		//this code ll insert total amount of the data

		$refund=mysql_fetch_array(mysql_query("select refund, ftype from fee_type where fee_id='$feeType1'"));
		
		//fee head wise total amount to be paid
		$feeheadtotal=mysql_fetch_row(mysql_query("select amount from `fee_m_descrption_head_total` where uid='$uid' and head_id='$feeType1' and sts=1"));			
		
		//fee head wise total amount  paid by student
		$feePaidheadtotal=mysql_fetch_row(mysql_query("select sum(totalAmount) from `fee_m_head_inst_collected` where studentId='$stud_id' and feeHead='$feeType1' and status=1"));	
		$fee1amt=mysql_fetch_array(mysql_query("select totalCollected, cleared from `fee_m_head_total` where feeHead='$feeType1' and studentId='$stud_id' and status=1"));
		if($fee1amt[0])
		{

			if(!$fee1amt[1])
			{	
				if($feePaidheadtotal[0]==$feeheadtotal[0] and $refund[1]==1)
				{
					$sql15="update `fee_m_head_total` set totalCollected='$feePaidheadtotal[0]', cleared=1 where feeHead='$feeType1' and studentId='$stud_id' and status=1";
				}
				else
				{
					$sql15="update `fee_m_head_total` set totalCollected='$feePaidheadtotal[0]' where feeHead='$feeType1' and studentId='$stud_id' and status=1";	
				}
				mysql_query($sql15);
			}
		}
		else
		{

			if($feeRecVal1==$feeheadtotal[0] and $refund[1]==1)
			{
				mysql_query("INSERT `fee_m_head_total` (`uid`, `accYear`, `studentId`, `feeHead`,  `oneTime`, `totalCollected`, `refund`, `refundAmount`, `cleared`, `status`) VALUES ('$uid', '$stud_yr', '$stud_id', '$feeType1', '$refund[1]', '$feeRecVal1', '$refund[0]', '', '1', '1')");
			}
			else
			{
				mysql_query("INSERT `fee_m_head_total` (`uid`, `accYear`, `studentId`, `feeHead`, `oneTime`, `totalCollected`, `refund`, `refundAmount`, `cleared`, `status`) VALUES ('$uid', '$stud_yr', '$stud_id', '$feeType1',  '$refund[1]', '$feeRecVal1', '$refund[0]', '', '', '1')");		
			}
		}
		
	
	}
	

}
?>
</body>
</html>
